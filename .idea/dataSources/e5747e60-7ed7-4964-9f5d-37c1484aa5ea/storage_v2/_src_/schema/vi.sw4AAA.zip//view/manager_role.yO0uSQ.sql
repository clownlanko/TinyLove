create view manager_role as
select `vim`.`user_id`          AS `user_id`,
       `viu`.`user_name`        AS `user_name`,
       `viu`.`password`         AS `password`,
       `viu`.`phone`            AS `phone`,
       `viu`.`email`            AS `email`,
       `vij`.`job_name`         AS `job_name`,
       `vij`.`job_remark`       AS `job_remark`,
       `vim`.`salary`           AS `salary`,
       `via`.`authority_name`   AS `authority_name`,
       `via`.`authority_remark` AS `authority_remark`,
       `vim`.`status`           AS `status`
from ((((`vi`.`vi_manager` `vim` join `vi`.`vi_role` `vir` on ((`vim`.`user_id` = `vir`.`user_id`))) join `vi`.`vi_authority` `via` on ((`via`.`authority_id` = `vir`.`authority_id`))) join `vi`.`vi_job` `vij` on ((`vij`.`job_id` = `vim`.`job_id`)))
       join `vi`.`vi_user` `viu` on ((`viu`.`user_id` = `vim`.`user_id`)));

